/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ipd12.Java3.Project.StockTracker;

import java.util.ArrayList;

/**
 *
 * @author 1796143
 */
public class Globals {
    static User currentUser;
    static Portfolio currentPortfolio;
    static boolean firstLoad = true;
    static ArrayList<Trade> currentTradesSet;
}
