
package ipd12.Java3.Project.StockTracker;

import java.util.ArrayList;

public class Globals {
    static User currentUser;
    static Portfolio currentPortfolio;
    static boolean firstLoad = true;
    static ArrayList<Trade> currentTradesSet;
    Object [][] currentTableData;
    static long selectedTradeID;
}
